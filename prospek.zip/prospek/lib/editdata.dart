import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Detail.dart';
import 'main.dart';
import 'package:prospek/editdata.dart';

class EditData extends StatefulWidget {
  final List list;
  final int index;
  EditData({this.list, this.index});

  @override
  _EditDataState createState() => _EditDataState();
}

class _EditDataState extends State<EditData> {
  TextEditingController namacontroller = new TextEditingController();
  TextEditingController tanggalcontroller = new TextEditingController();
  TextEditingController nohpcontroller = new TextEditingController();
  TextEditingController rencanacontroller = new TextEditingController();
  TextEditingController tipecontroller = new TextEditingController();
  TextEditingController alamatcontroller = new TextEditingController();
  TextEditingController keterangancontroller = new TextEditingController();
  TextEditingController statuscontroller = new TextEditingController();


  void editData() {
    var url = "http://192.168.0.9/dataprospek/editprospek.php";
    http.post(url, body: {
      "namaProspek": namacontroller.text,
      "tanggalProspek": tanggalcontroller.text,
      "NomorHp": nohpcontroller.text,
      "Rencana": rencanacontroller.text,
      "TipeKendaraan": tipecontroller.text,
      "AlamatProspek": alamatcontroller.text,
      "Keterangan": keterangancontroller.text,
      "statusProspek": statuscontroller.text
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    namacontroller =
        new TextEditingController(text: widget.list[widget.index]['nama']);
    tanggalcontroller =
        new TextEditingController(text: widget.list[widget.index]['tanggalProspek']);
    nohpcontroller =
    new TextEditingController(text: widget.list[widget.index]['NomorHp']);
    rencanacontroller =
    new TextEditingController(text: widget.list[widget.index]['Rencana']);
    tipecontroller =
    new TextEditingController(text: widget.list[widget.index]['TipeKendaraan']);
    alamatcontroller =
    new TextEditingController(text: widget.list[widget.index]['AlamatProspek']);
    keterangancontroller =
    new TextEditingController(text: widget.list[widget.index]['Keterangan']);
    statuscontroller =
    new TextEditingController(text: widget.list[widget.index]['statusProspek']);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: Text('Edit Data ${namacontroller.text}'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(children: <Widget>[
          new Column(
            children: <Widget>[
              new Padding(padding: new EdgeInsets.only(top: 15.0)),
              new TextField(
                  controller: namacontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Nama Prospek",
                      labelText: "Nama Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Tanggal Prospek",
                      labelText: "Tanggal Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Nomor HandPhone",
                      labelText: "Nomor HandPhone",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Rencana Pembelian",
                      labelText: "Rencana Pembelian",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Type Kendaraan",
                      labelText: "Type Kendaraan",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Alamat Prospek",
                      labelText: "Alamat Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Keterangan Prospek",
                      labelText: "Keterangan Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),

              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: statuscontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Status Prospek",
                      labelText: "Status Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: const EdgeInsets.all(5.0)),
              new RaisedButton(
                  child: new Text("Edit Data"),
                  color: Colors.blueAccent,
                  onPressed: () {
                    editData();
                    Navigator.of(context).push(new MaterialPageRoute(
                        builder: (BuildContext context) => new MyApp()));
                  })
            ],
          ),
        ]),
      ),
    );
  }
}
