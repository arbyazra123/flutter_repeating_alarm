import 'package:flutter/material.dart';
import 'editdata.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:ui';


FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

void main() async {
  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  runApp(
    MaterialApp(
      home: Detail(),
    ),
  );
}

class PaddedRaisedButton extends StatelessWidget {
  final String buttonText;
  final VoidCallback onPressed;
  const PaddedRaisedButton(
      {@required this.buttonText, @required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(5.0),
      child: RaisedButton(child: Text(buttonText), onPressed: onPressed),
    );
  }
}


class Detail extends StatefulWidget {
  List list;
  int index;
  Detail({this.list, this.index});
  @override
  _DetailState createState() => _DetailState();

}

class _DetailState extends State<Detail> {
  void deletedata() {
    var url = "http://192.168.0.9/dataprospek/deleteData.php";
    http.post(url, body: {'id': widget.list[widget.index]['id']});
  }



  void confirm() {
    AlertDialog alertDialog = new AlertDialog(
      content: new Text(
          "Are You Sure want to delete '${widget.list[widget.index]['nama']}'"),
      actions: <Widget>[
        new RaisedButton(
            child: new Text(
              'OK DELETE!',
              style: TextStyle(color: Colors.black),
            ),
            color: Colors.red,
            onPressed: () {
              deletedata();
              Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) => new MyApp()));
            }),
        new RaisedButton(
          child: new Text(
            'CANCEL',
            style: TextStyle(color: Colors.black),
          ),
          color: Colors.green,
          onPressed: () => Navigator.pop(context),
        ),
      ],
    );
    showDialog(context: context, child: alertDialog);
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
    home: Scaffold(
        appBar: new AppBar(
          leading: new Icon(Icons.person),
            title:
            new Text("${widget.list[widget.index]['nama']}")),
        backgroundColor: Colors.white,
        body: Container(
          margin: EdgeInsets.all(10.0),
          child: ListView(
            children: <Widget>[
              buildCard("Nama Prospect       : ${widget.list[widget.index]['nama']}"),
              buildCard("Tanggal Prospect    : ${widget.list[widget.index]['tanggal']}"),
              buildCard("Nomor HandPhone  : ${widget.list[widget.index]['nohp']}"),
              buildCard("Rencana Pembelian : ${widget.list[widget.index]['rencana']}"),
              buildCard("Type Kendaraan        : ${widget.list[widget.index]['tipe']}"),


              new Card(
                elevation: 5,
                child: Column(

                  children: <Widget>[
                    Container(
                        margin: EdgeInsets.all(5.0),
                        alignment: Alignment.topLeft,
                        child:
                        Text("Alamat                       :\n\n ${widget.list[widget.index]['alamat']}\n")
                    ),
                  ],
                ),
              ),

              new Card(
                elevation: 5,
                child: Column(

                  children: <Widget>[
                    Container(
                        margin: EdgeInsets.all(5.0),
                        alignment: Alignment.topLeft,
                        child:
                        Text("Keterangan                 : \n\n${widget.list[widget.index]['ket']}\n",
                        )
                    ),
                  ],
                ),
              ),

            new Card(
              elevation: 5,
              child: Column(
                children: <Widget>[
                  Container(
                      margin: EdgeInsets.all(5.0),
                      alignment: Alignment.center,
                      child:
                      Text("***** Status Prospect : ${widget.list[widget.index]['status']} *****\n",style: TextStyle(fontWeight: FontWeight.bold),)
                  ),
                ],
              ),
            ),



            new Card(
                elevation: 5,
            child: Column(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(5.0),
                    child: Text(
                        'BUAT REMINDER PROSPEK ANDA !!'),
                  ),
                  new Padding(padding: const EdgeInsets.only(top: 1.0)),
                  PaddedRaisedButton(
                    buttonText:
                    'Buat Setiap Hari Jam 10 Pagi !!',
                    onPressed: () async {
                      await _showDailyAtTime();
                    },
                  ),

              PaddedRaisedButton(
                buttonText:
                'Buat Setiap Hari (Senin) Jam 10 Pagi !!',
                onPressed: () async {
                  await _showWeeklyAtDayAndTime();
                },
              ),
                  PaddedRaisedButton(
                    buttonText: 'Test Notifikasi Reminder',
                    onPressed: () async {
                      await _showNotification();
                    },
                  ),
                ])),

          new Padding(padding: const EdgeInsets.only(top: 10.0)),
          new Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new Expanded(
                  child:
              new RaisedButton(
                child: Icon(Icons.edit),
                color: Colors.blue,
                onPressed: () => Navigator.of(context)
                    .push(new MaterialPageRoute(
                  builder: (BuildContext context) =>
                  new EditData(
                    list: widget.list,
                    index: widget.index,
                  ),
                )),
              )),

              Padding(
                padding: const EdgeInsets.all(5.0),
              ),

              new Expanded(
                child:
              new RaisedButton(
                child: Icon(Icons.delete),
                color: Colors.red,
                onPressed: () => confirm(),

              ))],
             ),
          ])),

        ));
  }

  Card buildCard(String text) {
    return Card(
              elevation: 5,
              child: Row(
                children: <Widget>[
                  Container(margin: EdgeInsets.all(5.0),
                  child:
                      Text(text)
                  ),
                ],
              ),
            );
  }

  Future<void> _showNotification() async {
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'your channel id', 'your channel name', 'your channel description',
        importance: Importance.Max, priority: Priority.High, ticker: 'ticker');
    var iOSPlatformChannelSpecifics = IOSNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
        androidPlatformChannelSpecifics, iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(
        0, 'plain title', 'plain body', platformChannelSpecifics,
        payload: 'item x');
  }

  Future<void> _showWeeklyAtDayAndTime() async {
    var time = Time(10, 0, 0);
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'show weekly channel id',
        'show weekly channel name',
        'show weekly description');
    var iOSPlatformChannelSpecifics = IOSNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
        androidPlatformChannelSpecifics, iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.showWeeklyAtDayAndTime(
        0,
        'show weekly title',
        'Weekly notification shown on Monday at approximately ${_toTwoDigitString(time.hour)}:${_toTwoDigitString(time.minute)}:${_toTwoDigitString(time.second)}',
        Day.Monday,
        time,
        platformChannelSpecifics);
  }Future<void> _showDailyAtTime() async {
    var time = Time(10, 0, 0);
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'repeatDailyAtTime channel id',
        'repeatDailyAtTime channel name',
        'repeatDailyAtTime description');
    var iOSPlatformChannelSpecifics = IOSNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
        androidPlatformChannelSpecifics, iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.showDailyAtTime(
        0,
        'show daily title',
        'Daily notification shown at approximately ${_toTwoDigitString(time.hour)}:${_toTwoDigitString(time.minute)}:${_toTwoDigitString(time.second)}',
        time,
        platformChannelSpecifics);
  }


  Future<void> onSelectNotification(String payload) async {
    if (payload != null) {
      debugPrint('notification payload: ' + payload);
    }

    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SecondScreen(payload)),
    );
  }

  String _toTwoDigitString(int value) {
    return value.toString().padLeft(2, '0');
  }

  Future<void> onDidReceiveLocalNotification(
      int id, String title, String body, String payload) async {
    // display a dialog with the notification details, tap ok to go to another page
    await showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: title != null ? Text(title) : null,
        content: body != null ? Text(body) : null,
        actions: [
          CupertinoDialogAction(
            isDefaultAction: true,
            child: Text('Ok'),
            onPressed: () async {
              Navigator.of(context, rootNavigator: true).pop();
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SecondScreen(payload),
                ),
              );
            },
          )
        ],
      ),
    );
  }
}

class SecondScreen extends StatefulWidget {
  SecondScreen(this.payload);

  final String payload;

  @override
  State<StatefulWidget> createState() => SecondScreenState();
}

class SecondScreenState extends State<SecondScreen> {
  String _payload;
  @override
  void initState() {
    super.initState();
    _payload = widget.payload;
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Second Screen with payload: ${(_payload ?? '')}'),
      ),
      body: Center(
        child: RaisedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Icon(Icons.delete),
          color: Colors.red,
        ),
      ),
    );
  }

}
