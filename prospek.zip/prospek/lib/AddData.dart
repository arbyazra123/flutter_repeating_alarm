import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'main.dart';
import 'dart:io';
import 'package:async/async.dart';

class AddData extends StatefulWidget {
  @override
  _AddDataState createState() => _AddDataState();
}

class _AddDataState extends State<AddData> {
  TextEditingController namacontroller = new TextEditingController();
  TextEditingController tanggalcontroller = new TextEditingController();
  TextEditingController nohpcontroller = new TextEditingController();
  TextEditingController rencanacontroller = new TextEditingController();
  TextEditingController tipecontroller = new TextEditingController();
  TextEditingController alamatcontroller = new TextEditingController();
  TextEditingController keterangancontroller = new TextEditingController();
  TextEditingController statuscontroller = new TextEditingController();

  void addData() {
    var url = "http://192.168.0.9/dataprospek/adddata.php";
    http.post(url, body: {
      "namaProspek": namacontroller.text,
      "tanggalProspek": tanggalcontroller.text,
      "NomorHp": nohpcontroller.text,
      "Rencana": rencanacontroller.text,
      "TipeKendaraan": tipecontroller.text,
      "AlamatProspek": alamatcontroller.text,
      "Keterangan": keterangancontroller.text,
      "statusProspek": statuscontroller.text
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: Text('Tambah Prospek Baru'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(children: <Widget>[
          new Column(
            children: <Widget>[
              new Padding(padding: new EdgeInsets.only(top: 15.0)),
              new TextField(
                  controller: namacontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Nama Prospek",
                      labelText: "Nama Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Tanggal Prospek",
                      labelText: "Tanggal Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Nomor HandpHone",
                      labelText: "Nomor HandpHone",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Rencana Pembelian",
                      labelText: "Rencana Pembelian",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Type Kendaraan",
                      labelText: "Type Kendaraan",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Alamat Prospek",
                      labelText: "Alamat Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: tanggalcontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Keterangan Prospek",
                      labelText: "Keterangan Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),

              new Padding(padding: new EdgeInsets.all(5.0)),
              new TextField(
                  controller: statuscontroller,
                  decoration: new InputDecoration(
                      hintText: "Input Status Prospek",
                      labelText: "Status Prospek",
                      border: new OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0)))),
              new Padding(padding: const EdgeInsets.all(5.0)),
              new RaisedButton(
                  child: new Text("BUAT PROSPEK BARU"),
                  color: Colors.green,
                  onPressed: () {
                    addData();
                    Navigator.of(context).push(new MaterialPageRoute(
                        builder: (BuildContext context) => new MyApp()));
                  })
            ],
          ),
        ]),
      ),
    );
  }
}
